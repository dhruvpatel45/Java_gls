package car.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Showcars
 */
@WebServlet("/Showcars")
public class Showcars extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Showcars() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set the content type
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            conn = DriverManager.getConnection("jdbc:mysql://128.66.203.247/imsc7it54", "imsc7it54", "sumo@123");

            // Prepare SQL query
            String sql = "SELECT * FROM car";
            pstmt = conn.prepareStatement(sql);

            // Execute query
            rs = pstmt.executeQuery();

            // Start generating HTML response
            out.println("<html>");
            out.println("<head><title>Car Details</title></head>");
            out.println("<body>");
            out.println("<h1>Car Details</h1>");

            // Start table
            out.println("<table border='1' cellpadding='10' cellspacing='0'>");
            out.println("<thead>");
            out.println("<tr>");
            out.println("<th>Car ID</th>");
            out.println("<th>Car Name</th>");
            out.println("<th>Car Price</th>");
            out.println("</tr>");
            out.println("</thead>");
            out.println("<tbody>");

            // Process result set
            while (rs.next()) {
                String carId = rs.getString("car_id");
                String carName = rs.getString("car_name");
                String carPrice = rs.getString("car_price");

                out.println("<tr>");
                out.println("<td>" + carId + "</td>");
                out.println("<td>" + carName + "</td>");
                out.println("<td>" + carPrice + "</td>");
                out.println("</tr>");
            }

            out.println("</tbody>");
            out.println("</table>");
            out.println("<br><a href='Insertcar'>Insert car</a>");
            out.println("<br><a href='index.jsp'>Go Back</a>");
            out.println("</body>");
            out.println("</html>");

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            out.println("<p>Error: JDBC Driver not found.</p>");
        } catch (SQLException e) {
            e.printStackTrace();
            out.println("<p>Error: Database access error.</p>");
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

   
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward POST requests to doGet
        doGet(request, response);
    }
}
